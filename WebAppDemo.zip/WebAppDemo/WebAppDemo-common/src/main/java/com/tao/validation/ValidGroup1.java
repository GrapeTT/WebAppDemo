package com.tao.validation;

/**
 * @Name：ValidGroup1
 * @Package：com.tao.validation
 * @Descripition：校验分组
 * @Author：涛
 * @Date：2018/4/4 21:56
 * @Version：1.0
 */
public interface ValidGroup1 {
    //接口中不需要定义任何方法，仅是对不同的校验规则进行分组
}
